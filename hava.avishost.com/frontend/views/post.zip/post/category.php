

<?php

use yii\helpers\Url;

$site_base = dirname(dirname(dirname(dirname(__FILE__))));
?>

<section  class="product-single ">
    <div class="container" style="padding-top: 50px;">

        <section class="main-blog vc-main-blog">
            <div class="container">

                <?php foreach ($cats as $catss) { ?>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="info">


                                <h2>
                                    <a href="<?= Url::to(['post/view', 'id' => $catss->post->id]) ?>" class="name"><?= $catss->post->title ?></a>
                                </h2>
                                <div class="text"><?= $catss->post->summary ?></div>


                                <a  href="<?= Url::to(['/post/view', 'id' => $catss->post->id]) ?>"   >
                                    <button class="btn btn-default" style="margin-top: 100px;">
                                        ادامه 
                                        <i class="fa fa-arrow-circle-left" aria-hidden="true"></i>
                                    </button>
                                </a>
                            </div>
                            </br>
                        </div>
                        <div class="col-md-5">

                            <div class="">
                                <a  href="<?= Url::to(['post/view', 'id' => $catss->post->id]) ?>">
                                    <img  src="<?PHP echo common\models\Post::resize_img($site_base . '/backend/web/' . $catss->post->THUMnail, 450, 262, "_" . $catss->post->id); ?>" class="attachment-img270x180 size-img270x180 wp-post-image"  />
                                </a>
                            </div>
                            </br>
                        </div>





                        <div class="clearfix"> </div>
                    </div>
                <?php } ?>
            </div>

        </section>
    </div>
    

</section>
