

<?php

use yii\helpers\Url;

$site_base = dirname(dirname(dirname(dirname(__FILE__))));
?>

<section  class="product-single ">
    <div class="container" style="padding-top: 50px;">

        <section class="main-blog vc-main-blog">
            <div class="container">

                <h1>
                                    <?= \common\models\Category::findOne($_GET['id'])->name; ?>
                                </h1>
                <p>
                    <?= \common\models\Category::findOne($_GET['id'])->body; ?>
                </p>
                <div class="row" style="margin-top: 30px;" >
                <?php foreach ($cats as $catss) { ?>
                   
                        <div class="col-md-4">
                            <div class="info">


                                
                                <a  href="<?= Url::to(['post/view', 'id' => $catss->post->id]) ?>">
                                    <img  src="<?PHP echo common\models\Post::resize_img($site_base . '/backend/web/' . $catss->post->THUMnail, 390, 496, "_" . $catss->post->id); ?>" class="attachment-img270x180 size-img270x180 wp-post-image"  />
                                </a>
                                <div style="height: 30px"> </div>
                                <h2>
                                    <?= $catss->post->title ?> 
                                </h2>
                                


                                <a  href="<?= Url::to(['/post/view', 'id' => $catss->post->id]) ?>"   >
                                    <button class="btn btn-default" style="margin-top: 20px;">
                                        اطلاعات بیشتر
                                        <i class="fa fa-arrow-circle-left" aria-hidden="true"></i>
                                    </button>
                                </a>
                            </div>
                            </br>
                        </div>
                        





                       
                    
                <?php } ?>
                     </div>
            </div>

        </section>
    </div>
    

</section>
