<style>
    h1 {
    text-align: center;
}
</style>
                    <header class="entry-header page-head" style=" margin-top:150px; background-color:#fff;background-image:url('/page-head-bg.jpg')">
	
			<div class="col-md-12">
                            <center>
				<h1>
				<?= $model->title ?>		</h1>
                            </center>
			</div>
		
	</div>
</header>
			<!-- POST CONTENT -->
			<article id="post-78" class="post-78 post type-post status-publish format-standard has-post-thumbnail hentry category-blog tag-best tag-cappuccino tag-coffee text-page-wrap">
				<!-- .entry-content -->
				<div class="entry-content container">
					<div class="row">
					
<div class="col-md-8">
	<div class="blog-post text-page">

		<div class="img-wrap"><img width="770" height="500" src="/backend/web/<?= $model->THUMnail ?>" class="attachment-img770x500 size-img770x500 wp-post-image" alt="image" /></div>
	

		<p><?= $model->summary ?>	</p>

	
		
<div id="comments" class="comments-area">

	
	<!-- #respond -->
	
</div><!-- .comments-area -->




	</div>
</div>


	<!-- SIDEBAR -->
	<aside id="secondary" class="col-md-4 sidebar">
		<div class="widget-area" role="complementary">
			<div id="categories-2" class="widget widget_categories"><h4 class="widget-title"> مطالب مرتبط </h4>
                             <ul>
                           <?php 
                                                 $pst = common\models\CategoryHasPost::find()
                                            ->innerJoinWith('post', '')
                                            ->andWhere(['category_id' => 6]) 
                                            ->all();
                                                
                                                 
                                    foreach ($pst as $posts){ ?>
                           
	<li class="cat-item cat-item-15"><a href="" ><?= $posts->post->title ?></a>
</li>
                                    <?php } ?>
		</ul>
</div>
                    <!-- WIDGETS END -->
		</div>
	</aside>
	<!-- SIDEBAR END -->



 


					</div>
				</div>
				<!-- .entry-content end-->
			</article>
			<!-- POST CONTENT END -->
              